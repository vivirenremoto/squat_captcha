
var captcha_done = false;
var captcha_operation = false;
var captcha_url = 'https://vivirenremoto.github.io/squat_captcha/';

function captcha_complete(e) {

    if (e.origin.indexOf('vivirenremoto.github.io') > -1) {

        captcha_done = true;
        jQuery('#squat_captcha').remove();
        jQuery('#a-page').show();

        if (captcha_operation == 'cart') {
            jQuery('#add-to-cart-button').click();
        } else if (captcha_operation == 'buy') {
            jQuery('#buy-now-button').click();
        }

    }
}


function showCaptcha() {
    if (captcha_done == false) {

        jQuery('#a-page').hide();
        jQuery('body').append('<iframe allow="camera;microphone" id="squat_captcha" src="' + captcha_url + '" style="background:#fff;border:0;position:fixed;top:0;left:0;width:100%;height:100%;"></iframe>');

        window.addEventListener('message', captcha_complete, false);

    }
}



jQuery(function () {

    if (document.location.href.indexOf('/dp/') > -1 || document.location.href.indexOf('/gp/') > -1) {


        jQuery('#add-to-cart-button').click(function () {

            if (!captcha_done) {
                captcha_operation = 'cart';
                showCaptcha();
                event.preventDefault();
                return;
            }

        });

        jQuery('#buy-now-button').click(function () {

            if (!captcha_done) {
                captcha_operation = 'buy';
                showCaptcha();
                event.preventDefault();
                return;
            }

        });




    }

});





